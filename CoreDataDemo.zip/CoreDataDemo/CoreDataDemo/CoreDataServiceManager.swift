//
//  CoreDataServiceManager.swift
//  GDR2
//
//  Created by Hardik Agile on 07/03/17.
//  Copyright © 2017 Agile Infoways P. Ltd. All rights reserved.
//

import UIKit
import CoreData

class CoreDataServiceManager: NSObject {

    class func getContext() -> NSManagedObjectContext{
        
        let appdeleget = UIApplication.shared.delegate as! AppDelegate
        return appdeleget.persistentContainer.viewContext
    }
    
    class func storeEmployee(employeeDetail: [String:Any])
    {
        print(employeeDetail)
        let context = getContext()
        
        let entity = NSEntityDescription.entity(forEntityName: "Employee", in: context)
        let manageObj = NSManagedObject(entity: entity!, insertInto: context)
        manageObj.setValuesForKeys(employeeDetail)
        print(manageObj)
        
        do{
            try context.save()
            print("saved.")
        }catch{
            print(error.localizedDescription)
        }
    }
    
    class func getEmployees() -> [Employee]
    {
        var result = [Employee]()
        let fetchRequest: NSFetchRequest = Employee.fetchRequest()
        do{
            result = try getContext().fetch(fetchRequest)
        }catch{
            print(error.localizedDescription)
        }
        return result
    }
    
    class func getEmployeeBy(id: String) -> [Employee]
    {
        var result = [Employee]()
        let fetchRequest: NSFetchRequest = Employee.fetchRequest()
        let predicate = NSPredicate(format: "emo_id == %@","\(id)")
        fetchRequest.predicate = predicate
        do{
            result = try getContext().fetch(fetchRequest)
        }catch{
            print(error.localizedDescription)
        }
        return result
    }

    class func updateEmployee(id: NSManagedObjectID, dict: [String:Any]){
        let context = getContext()
        let sugerToUpdate = getById(id: id)
        sugerToUpdate.setValuesForKeys(dict)
        do{
            try context.save()
            print("Update.")
        }catch{
            print(error.localizedDescription)
        }
    }
    
    class func getById(id: NSManagedObjectID) -> NSManagedObject{
        let context = getContext()
        return context.object(with: id)
    }

    class func deleteEmployee(id: NSManagedObjectID){
        let context = getContext()
        let sugerToDelete = getById(id: id)
        context.delete(sugerToDelete)
        do{
            try context.save()
            print("saved.")
        }catch{
            print(error.localizedDescription)
        }
    }
    
    class func clearCoreData()
    {
        let fetchRequest:NSFetchRequest<Employee> = Employee.fetchRequest()
        let deleteRequest = NSBatchDeleteRequest(fetchRequest: fetchRequest as! NSFetchRequest<NSFetchRequestResult>)
        do{
            print("deleting all elements")
            try getContext().execute(deleteRequest)
        }
        catch
        {
            print("error in clear data = \(error.localizedDescription)")
        }
    }
}
